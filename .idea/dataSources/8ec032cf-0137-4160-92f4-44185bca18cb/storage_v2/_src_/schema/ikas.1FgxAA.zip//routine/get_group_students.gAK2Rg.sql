create procedure get_group_students()
  SELECT DISTINCT `Group`.`name_group` FROM `Group`, `User` WHERE `User`.`position` = 'студент' AND `Group`.`id_group` = `User`.`id_group`;

