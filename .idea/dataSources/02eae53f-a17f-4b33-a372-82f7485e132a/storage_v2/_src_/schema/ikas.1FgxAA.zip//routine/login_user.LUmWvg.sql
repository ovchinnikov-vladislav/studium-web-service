create procedure login_user(IN loginP varchar(30), IN passwordP varchar(255))
  SELECT * FROM `User`, `Group` WHERE `User`.`login` = loginP AND `User`.`password` = passwordP AND `User`.`id_group` = `Group`.`id_group`;

