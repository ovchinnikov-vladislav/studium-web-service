create procedure get_positions()
  SELECT DISTINCT `User`.`position` FROM `User`;

