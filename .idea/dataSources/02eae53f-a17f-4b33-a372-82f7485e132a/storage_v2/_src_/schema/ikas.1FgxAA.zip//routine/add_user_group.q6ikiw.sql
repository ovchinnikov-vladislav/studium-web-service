create procedure add_user_group(IN groupName varchar(20), IN groupDir varchar(30), IN fioUser varchar(60),
                                IN loginUser varchar(30), IN passwordUser varchar(255), IN phoneUser varchar(15),
                                IN emailUser varchar(60), IN positionUser varchar(30), IN accessUser tinyint)
  BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
    	ROLLBACK;
        SELECT 'Error';
    END;
    SET AUTOCOMMIT = 0;
    IF ((SELECT COUNT(*) FROM `Group` WHERE name_group = groupName) = 0)
    THEN
		INSERT INTO `Group` (name_group, direction) VALUE (groupName, direction);
    END IF;
    INSERT INTO `User` (fio, login, `password`, date_reg, phone, email, status_pass, position, access, id_group) VALUE (fioUser, loginUser, passwordUser, Now(), phoneUser, emailUser, 0, positionUser, accessUser, (SELECT id_group FROM `Group` WHERE name_group = groupName));
    SELECT "Normal";
   COMMIT;
END;

