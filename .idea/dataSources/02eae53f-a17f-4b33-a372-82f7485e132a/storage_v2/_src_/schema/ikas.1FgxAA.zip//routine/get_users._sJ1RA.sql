create procedure get_users()
  SELECT `User`.`id_user`, `User`.`fio`, `User`.`login`, `User`.`date_reg`, `User`.`phone`, `User`.`email`, `User`.`status_pass`, `User`.`position`, `User`.`access`, `Group`.`name_group` FROM `User`, `Group` WHERE `User`.`id_group` = `Group`.`id_group`;

